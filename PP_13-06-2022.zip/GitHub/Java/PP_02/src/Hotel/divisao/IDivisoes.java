/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hotel.divisao;

import Dados_Pessoa.Pessoa;

/**
 *
 * @author PC
 */
public interface IDivisoes {

    public String getNomeDivisao();

    public int getNumMaxSuporte();

    public Pessoa[] getPessoasDivisao();
    
}
