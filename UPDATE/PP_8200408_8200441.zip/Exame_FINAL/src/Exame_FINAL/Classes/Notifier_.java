/* 
* Nome: Marcio Samuel Santos Ribeiro
* Número: 8200408
* Turma: LEI2T4
* 
* Nome: Hugo Miguel Gomes Alves Ribeiro
* Número: 8200441
* Turma: LEI2T3
*/
package Exame_FINAL.Classes;

import estgconstroi.Employee;
import estgconstroi.Notifier;
import estgconstroi.enums.EventPriority;

/**
 *
 * @author PC
 */
public class Notifier_ implements Notifier {

    private final String message;
    private final EventPriority event_priority;
    private final Employee empl;

    /**
     *
     * @param string
     * @param ep
     * @param empl
     */
    public Notifier_(String message, EventPriority event_priority, Employee empl) {
        this.message = message;
        this.event_priority = event_priority;
        this.empl = empl;

        this.notify(message, event_priority, empl);
    }

    /**
     *
     * @param string - the message to be notified.
     * @param ep - Event Priority.
     * @param empl - the Employee to be notified.
     */
    @Override
    public void notify(String string, EventPriority ep, Employee empl) {
        System.out.println("Employee notified: " + empl.toString()
                + "\nPriority:" + ep + "\nMessage:" + string);
    }

}
