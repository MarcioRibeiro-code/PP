/* 
* Nome: Marcio Samuel Santos Ribeiro
* Número: 8200408
* Turma: LEI2T4
* 
* Nome: Hugo Miguel Gomes Alves Ribeiro
* Número: 8200441
* Turma: LEI2T3
*/
package Exame_FINAL.Exceptions;

/**
 *
 * @author PC
 */
public class ManagerException extends Exception{

    /**
     *
     */
    public ManagerException() {
    }

    /**
     *
     * @param string
     */
    public ManagerException(String message) {
        super(message);
    }
    
}
